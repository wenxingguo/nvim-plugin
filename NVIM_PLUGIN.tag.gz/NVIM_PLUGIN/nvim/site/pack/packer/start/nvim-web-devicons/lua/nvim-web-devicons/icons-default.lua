return {
  icons_by_filename = require "nvim-web-devicons.default.icons_by_filename",
  icons_by_file_extension = require "nvim-web-devicons.default.icons_by_file_extension",
  icons_by_operating_system = require "nvim-web-devicons.default.icons_by_operating_system",
  icons_by_desktop_environment = require "nvim-web-devicons.default.icons_by_desktop_environment",
  icons_by_window_manager = require "nvim-web-devicons.default.icons_by_window_manager",
}
