@ContextConfiguration(
  classes = {
    WireMockConfig.class,
  }
)
public class Foo {

}
