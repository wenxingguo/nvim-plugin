int f1(int x) {
    return 1;
}

int f2(int x)
{
    return 1;
}

int f3(
    int x
) {
    return 1;
}

int f4(
    int x,
    int y
) {
    return 1;
}

int f5(int x,
       int y)
{
    return 1;
}

int
f6(int x, int y)
{
    return 1;
}
